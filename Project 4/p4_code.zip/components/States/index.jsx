import React from "react";
import "./styles.css";

/**
 * Define States, a React component of Project 4, Problem 2. The model
 * data for this view (the state names) is available at
 * window.models.statesModel().
 */
const States = () =>{
  console.log(
    "window.models.statesModel()",
    window.models.statesModel()
  );

  return <>Replace this with the code for Project 4, Problem 2</>
}
export default States;
